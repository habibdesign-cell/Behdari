<?php
// Define constants for status
class Status
{
    const ACTIVE = 'درحال انجام وظیفه';
    const LEAVE = 'ترخیص شده';
}

// Function to translate status
function translateStatus(string $status): string
{
    switch ($status) {
        case 'active':
            return Status::ACTIVE;
        case 'leave':
            return Status::LEAVE;
        default:
            return 'Unknown status';
    }
}

function alert(string $string, $type){
  if ($type = 'warning') {
    echo '<div class="alert alert-danger mt-3" role="alert">
          '.$string.'
          </div>';
  }elseif($type = 'caution'){
    echo '<div class="alert alert-warning mt-3" role="alert">
          '.$string.'
          </div>';
  }elseif($type = 'success'){
    echo '<div class="alert alert-success mt-3" role="alert">
          '.$string.'
          </div>';
  }
}

class Type
{
    const SOLDIER = 'وظیفه';
    const CADRE = 'پایور';
}

// Function to translate status
function translateType(string $type): string
{
    switch ($type) {
        case 'soldier':
            return Type::SOLDIER;
        case 'cadre':
            return Type::CADRE;
        default:
            return 'Unknown type';
    }
}

class Medal
{
  const MEDAL0 = 'مدیر سیستم';
  const MEDAL1 = 'سرباز وظیفه';
  const MEDAL2 = 'گروهبان سوم';
  const MEDAL3 = 'گروهبان دوم';
  const MEDAL4 = 'گروهبان یکم';
  const MEDAL5 = 'استوار دوم';
  const MEDAL6 = 'استوار یکم';
  const MEDAL7 = 'ستوان سوم';
  const MEDAL8 = 'ستوان دوم';
  const MEDAL9 = 'ستوان یکم';
  const MEDAL10 = 'سروان';
  const MEDAL11 = 'سرگرد';
  const MEDAL12 = 'سرهنگ دوم';
  const MEDAL13 = 'سرهنگ';
  const MEDAL14 = 'سرتیپ';
  const MEDAL15 = 'سرلشکر';

  const MEDAL0IMG = 'img/medal/1.png';
  const MEDAL1IMG = 'img/medal/1.png';
  const MEDAL2IMG = 'img/medal/2.png';
  const MEDAL3IMG = 'img/medal/3.png';
  const MEDAL4IMG = 'img/medal/4.png';
  const MEDAL5IMG = 'img/medal/5.png';
  const MEDAL6IMG = 'img/medal/6.png';
  const MEDAL7IMG = 'img/medal/7.png';
  const MEDAL8IMG = 'img/medal/8.png';
  const MEDAL9IMG = 'img/medal/9.png';
  const MEDAL10IMG = 'img/medal/10.png';
  const MEDAL11IMG = 'img/medal/11.png';
  const MEDAL12IMG = 'img/medal/12.png';
  const MEDAL13IMG = 'img/medal/13.png';
  const MEDAL14IMG = 'img/medal/14.png';
  const MEDAL15IMG = 'img/medal/15.png';
}

// Function to translate status
function translateMedal(string $medal): string
{
    switch ($medal) {
      case '0':
            return Medal::MEDAL0;
      case '1':
            return Medal::MEDAL1;
      case '2':
            return Medal::MEDAL2;
      case '3':
            return Medal::MEDAL3;
      case '4':
            return Medal::MEDAL4;
      case '5':
            return Medal::MEDAL5;
      case '6':
            return Medal::MEDAL6;
      case '7':
            return Medal::MEDAL7;
      case '8':
            return Medal::MEDAL8;
      case '9':
            return Medal::MEDAL9;
      case '10':
            return Medal::MEDAL10;
      case '11':
            return Medal::MEDAL11;
      case '12':
            return Medal::MEDAL12;
      case '13':
            return Medal::MEDAL13;
      case '14':
            return Medal::MEDAL14;
      case '15':
            return Medal::MEDAL15;
    }
}

function translateMedalIMG(string $medal): string
{
    switch ($medal) {
      case '0':
            return Medal::MEDAL0IMG;
      case '1':
            return Medal::MEDAL1IMG;
      case '2':
            return Medal::MEDAL2IMG;
      case '3':
            return Medal::MEDAL3IMG;
      case '4':
            return Medal::MEDAL4IMG;
      case '5':
            return Medal::MEDAL5IMG;
      case '6':
            return Medal::MEDAL6IMG;
      case '7':
            return Medal::MEDAL7IMG;
      case '8':
            return Medal::MEDAL8IMG;
      case '9':
            return Medal::MEDAL9IMG;
      case '10':
            return Medal::MEDAL10IMG;
      case '11':
            return Medal::MEDAL11IMG;
      case '12':
            return Medal::MEDAL12IMG;
      case '13':
            return Medal::MEDAL13IMG;
      case '14':
            return Medal::MEDAL14IMG;
      case '15':
            return Medal::MEDAL15IMG;
    }
}


// Define constants for status
class Good
{
    const ACTIVE = 'موجود';
    const LEAVE = 'اتمام';
}

// Function to translate status
function translateGood(string $status): string
{
    switch ($status) {
        case 'active':
            return Good::ACTIVE;
        case 'leave':
            return Good::LEAVE;
        default:
            return 'Unknown status';
    }
}

// Define constants for status
class Report
{
    const ACTIVE = 'افزودن';
    const LEAVE = 'حذف';
}

// Function to translate status
function translateReport(string $status): string
{
    switch ($status) {
        case 'active':
            return Report::ACTIVE;
        case 'leave':
            return Report::LEAVE;
        default:
            return 'ویرایش';
    }
}

// Define constants for status
class Repository
{
    const ACTIVE = 'سررشته داری';
    const LEAVE = 'تجهیزات پزشکی';
}

// Function to translate status
function translateRepository(string $status): string
{
    switch ($status) {
        case '1':
            return Repository::ACTIVE;
        case '2':
            return Repository::LEAVE;
        default:
            return 'نامشخص';
    }
}

function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return array($jy, $jm, $jd);
}
function translatenowDate(){
  $ydate = date('Y');
  $mdate = date('m');
  $ddate = date('d');
  $datenow = gregorian_to_jalali($ydate,$mdate,$ddate);
  $datenowstring = $datenow[0]."/".$datenow[1]."/".$datenow[2];
  return $datenowstring;
}

?>

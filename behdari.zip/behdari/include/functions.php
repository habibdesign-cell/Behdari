<?php
include("include/sql.php");

$conn = new mysqli($host, $user, $pass, $dbname);


?>

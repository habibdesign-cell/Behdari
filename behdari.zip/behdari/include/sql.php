<?php

//Database connection
$host = 'localhost';
$dbname = 'behdari';
$user = 'root'; // Replace with your database username
$pass = ''; // Replace with your database password

?>

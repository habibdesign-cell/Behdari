-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 05, 2025 at 09:01 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `behdari`
--

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE `drugs` (
  `name` varchar(255) NOT NULL,
  `code` int(11) NOT NULL,
  `organization_number` int(11) NOT NULL,
  `real_number` int(11) NOT NULL,
  `status` enum('active','leave') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`name`, `code`, `organization_number`, `real_number`, `status`) VALUES
('امپرازول 300', 97328, 1205, 25, 'active'),
('کلونوسپام', 151561, 20, 19, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `drugs_reports`
--

CREATE TABLE `drugs_reports` (
  `code` int(11) NOT NULL,
  `date` date NOT NULL,
  `number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('active','leave','edit') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `drugs_reports`
--

INSERT INTO `drugs_reports` (`code`, `date`, `number`, `user_id`, `status`) VALUES
(0, '0000-00-00', 0, 0, 'leave'),
(97328, '0000-00-00', 14, 371819849, 'active'),
(97328, '0000-00-00', 16, 371819849, 'edit'),
(97328, '0000-00-00', 20, 371819849, 'edit'),
(97328, '0000-00-00', 20, 371819849, 'edit'),
(97328, '0000-00-00', 20, 371819849, 'edit'),
(97328, '2025-02-15', 25, 371819849, 'edit'),
(97328, '2025-02-15', 25, 371819849, 'edit'),
(151561, '2025-02-15', 19, 371819849, 'active'),
(4524, '2025-02-15', 25, 371819849, 'active'),
(0, '2025-02-16', 0, 371819849, 'leave'),
(23897, '2025-02-16', 1205, 371819849, 'active'),
(23897, '2025-02-16', 1205, 371819849, 'leave');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `page_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `role_id`, `page_name`) VALUES
(1, 1, 'setting');

-- --------------------------------------------------------

--
-- Table structure for table `personnel`
--

CREATE TABLE `personnel` (
  `name` varchar(255) NOT NULL,
  `medal` int(11) NOT NULL,
  `code` int(11) NOT NULL,
  `personnel_code` int(11) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `birth` date NOT NULL,
  `dispatch` date NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `type` enum('cadre','soldier') NOT NULL,
  `status` enum('active','leave','mission') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `personnel`
--

INSERT INTO `personnel` (`name`, `medal`, `code`, `personnel_code`, `city`, `birth`, `dispatch`, `phone`, `type`, `status`) VALUES
('حبیب بهرامی', 0, 371819849, 5000, 'قم', '2025-02-03', '2025-02-02', 2147483647, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `psichology`
--

CREATE TABLE `psichology` (
  `id` int(11) NOT NULL,
  `date` varchar(10) DEFAULT NULL,
  `guards` text DEFAULT NULL,
  `cadre_interview` text DEFAULT NULL,
  `soldier_interview` text DEFAULT NULL,
  `drivers` text DEFAULT NULL,
  `dispatch` text DEFAULT NULL,
  `groupb` text DEFAULT NULL,
  `newbie` text DEFAULT NULL,
  `education` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `psichology`
--

INSERT INTO `psichology` (`id`, `date`, `guards`, `cadre_interview`, `soldier_interview`, `drivers`, `dispatch`, `groupb`, `newbie`, `education`) VALUES
(1, '۱۴۰۳/۱۲/۰۱', '25', '45', '45', '25', '25', '25', '25', 25),
(3, '0000-00-00', '45', '452', '245', '524', '254', '452', '524', 254),
(4, '0000-00-00', '514', '514', '154', '154', '154', '15', '514', 415),
(5, '0000-00-00', '25', '166', '154', '36', '154', '25', '4563', 564);

-- --------------------------------------------------------

--
-- Table structure for table `repository`
--

CREATE TABLE `repository` (
  `name` varchar(255) NOT NULL,
  `code` int(11) NOT NULL,
  `organization_number` int(11) NOT NULL,
  `real_number` int(11) NOT NULL,
  `burrow_number` int(11) NOT NULL,
  `repository` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `repository`
--

INSERT INTO `repository` (`name`, `code`, `organization_number`, `real_number`, `burrow_number`, `repository`) VALUES
('برانکارد', 97328, 51, 25, 600, '1');

-- --------------------------------------------------------

--
-- Table structure for table `repository_reports`
--

CREATE TABLE `repository_reports` (
  `code` int(11) NOT NULL,
  `date` date NOT NULL,
  `number` int(11) NOT NULL,
  `burrow_number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('active','leave','edit') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `repository_reports`
--

INSERT INTO `repository_reports` (`code`, `date`, `number`, `burrow_number`, `user_id`, `status`) VALUES
(97328, '2025-02-15', 25, 514, 0, 'edit'),
(97328, '2025-02-15', 25, 500, 0, 'edit'),
(97328, '2025-02-16', 25, 600, 0, 'edit'),
(97328, '2025-02-16', 25, 600, 0, 'edit'),
(5461, '2025-02-16', 21, 5, 0, 'active'),
(0, '2025-02-16', 0, 0, 371819849, 'leave');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'مدیر سیستم');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `code` int(12) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`code`, `username`, `password_hash`, `role_id`) VALUES
(371819849, 'user', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_login_details`
--

CREATE TABLE `user_login_details` (
  `code` int(11) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_login_details`
--

INSERT INTO `user_login_details` (`code`, `login_date`, `login_time`, `ip_address`, `user_agent`) VALUES
(371819849, '2025-02-10', '09:11:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36'),
(371819849, '2025-02-11', '05:05:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36'),
(371819849, '2025-02-13', '09:20:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36'),
(371819849, '2025-02-14', '08:50:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36'),
(371819849, '2025-02-15', '08:10:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'),
(371819849, '2025-02-16', '10:38:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'),
(371819849, '2025-02-17', '05:50:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'),
(371819849, '2025-02-28', '05:02:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'),
(371819849, '2025-02-28', '05:03:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'),
(371819849, '2025-03-01', '10:24:00', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `psichology`
--
ALTER TABLE `psichology`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`code`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `psichology`
--
ALTER TABLE `psichology`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `personnel`
--
ALTER TABLE `personnel`
  ADD CONSTRAINT `personnel_ibfk_1` FOREIGN KEY (`code`) REFERENCES `users` (`code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

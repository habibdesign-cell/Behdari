<script>
$(document).ready(function() {
    // Initialize the Jalali datepicker
    $('#jalali-datepicker').jalaliDatePicker({
        // Add any options you need here
    });

    // Activate the datepicker on focus
    $('#jalali-datepicker').focus(function() {
        $(this).jalaliDatePicker('show');
    });
});
</script>

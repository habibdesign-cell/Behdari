
    // Map of English to Farsi digits
    const englishToFarsiDigits = {
        "0": "۰",
        "1": "۱",
        "2": "۲",
        "3": "۳",
        "4": "۴",
        "5": "۵",
        "6": "۶",
        "7": "۷",
        "8": "۸",
        "9": "۹"
    };

    // Function to convert numbers to Farsi
    function convertNumbersToFarsi(container) {
        const elements = container.querySelectorAll("*"); // Select all elements
        elements.forEach(element => {
            if (element.children.length === 0) { // Ignore parent elements with children
                element.innerHTML = element.innerHTML.replace(/\d/g, (match) => {
                    return englishToFarsiDigits[match]; // Replace each digit
                });
            }
        });
    }

    // Apply the conversion to the entire body
    convertNumbersToFarsi(document.body);

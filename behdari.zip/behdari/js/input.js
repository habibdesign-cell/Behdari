
  document.querySelectorAll('input.form-control-simple').forEach(input => {
    // Create wrapper div
    const wrapper = document.createElement('div');
    wrapper.classList.add('form-control-simple');

    // Create span for placeholder text from input placeholder
    const placeholderSpan = document.createElement('span');
    placeholderSpan.classList.add('placeholder-text');
    placeholderSpan.textContent = input.getAttribute('placeholder');

    // Wrap the input
    input.parentNode.insertBefore(wrapper, input);
    wrapper.appendChild(input);
    wrapper.appendChild(placeholderSpan);

    // Clear native placeholder to avoid duplication
    input.setAttribute('placeholder', '');
  });


  const toggleSubmitBtn = document.getElementById('toggle-submit-btn');
  const formContainer = document.getElementById('form-container');
  const contactForm = document.getElementById('contact-form');

  toggleSubmitBtn.addEventListener('click', function () {
    if (!formContainer.classList.contains('active')) {
      // Show the form
      formContainer.classList.add('active');
      toggleSubmitBtn.textContent = 'Submit';
    } else {
      // Submit the form
      if (contactForm.reportValidity()) {
        alert('Form submitted successfully!');
        formContainer.classList.remove('active');
        toggleSubmitBtn.textContent = 'Show Form';
        contactForm.reset();
      }
    }
  });


  const menu = document.getElementById('sliding-menu');
  const overlay = document.getElementById('menu-overlay');
  const menuButton = document.getElementById('menu-button');

  // Open menu
  menuButton.addEventListener('click', () => {
    menu.classList.add('open');
    overlay.classList.add('show');
  });

  // Close menu on overlay click
  overlay.addEventListener('click', () => {
    menu.classList.remove('open');
    overlay.classList.remove('show');
  });
